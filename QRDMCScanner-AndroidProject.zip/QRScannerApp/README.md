# QR & DMC Scanner — Android App

## How to Build the APK

### Method 1: Android Studio (Recommended)
1. Download and install **Android Studio** from developer.android.com
2. Open Android Studio → "Open an Existing Project" → select this folder
3. Wait for Gradle sync to finish
4. Go to **Build → Build Bundle(s)/APK(s) → Build APK(s)**
5. The APK will be in `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer to your Android phone and install (enable "Install from unknown sources" in Settings)

### Method 2: Command Line (if Android SDK installed)
```bash
./gradlew assembleDebug
```

### Method 3: GitHub Actions (Free, No PC Setup)
1. Create a free GitHub account
2. Upload this folder as a new repository
3. Create `.github/workflows/build.yml`:
```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with: { java-version: '17', distribution: 'temurin' }
      - uses: android-actions/setup-android@v2
      - run: ./gradlew assembleDebug
      - uses: actions/upload-artifact@v3
        with:
          name: app-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```
4. Push your code → GitHub builds the APK → download from Actions tab

### Method 4: Online APK Builder (Easiest, No coding)
1. Go to https://www.appsgeyser.com
2. Choose "WebView" template
3. Paste the contents of `app/src/main/assets/index.html`
4. Download APK directly

## Features
- Live camera QR code scanning (rear + front camera)
- DataMatrix code support  
- Editable content with character counter
- Capacity bars for QR/DMC limits
- Scan history (last 50 scans)
- Flashlight toggle
- Works fully offline

## Requirements
- Android 5.0 (API 21) or higher
- Camera permission (granted at runtime)
